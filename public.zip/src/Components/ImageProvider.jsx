import Cart from "../assets/Baners-others/cart.png";
import Star from "../assets/Baners-others/star.png";
import Banana from "../assets/Products-img/banana.png";
import Boult from "../assets/Products-img/boult.jpg";
import Belt from "../assets/Products-img/belt.jpg";
import Cap from "../assets/Products-img/cap.jpg";
import Carrot from "../assets/Products-img/carrots.png";
import Orange from "../assets/Products-img/orange.png";
import Spinach from "../assets/Products-img/spinach.png";
import Sunglasses from "../assets/Products-img/Sunglasses.jpg";
import Tomato from "../assets/Products-img/tomatoes.png";
import Wallet from "../assets/Products-img/wallet.jpg";
import Apple from "../assets/Products-img/apple.png";
import Baner1 from "../assets/Baners-others/slide-img1.jpg";
import Baner2 from "../assets/Baners-others/slide-img2.jpg";
import FooterBaner1 from "../assets/Baners-others/footer-banner1.jpg";
import FooterBaner2 from "../assets/Baners-others/footer-banner2.jpg";
import Delivery from "../assets/Support-img/delivery.png";
import Payment from "../assets/Support-img/payment.png";
import Shipped from "../assets/Support-img/shipped.png";
import Technical from "../assets/Support-img/technical.png";
import Team from "../assets/About-us/hands.jpg";
import Vision from "../assets/About-us/visionary.jpg";
import Mission from "../assets/About-us/mission.jpg";
import Values from "../assets/About-us/leadership.jpg";

const images = {
  Team,
  Vision,
  Mission,
  Values,
  Cart,
  Star,
  Banana,
  Boult,
  Belt,
  Cap,
  Carrot,
  Orange,
  Spinach,
  Sunglasses,
  Tomato,
  Wallet,
  Apple,
  Baner2,
  Baner1,
  FooterBaner1,
  FooterBaner2,
  Delivery,
  Payment,
  Shipped,
  Technical,
};

export default images;
